#!/usr/bin/env node
// HSBC CCS System Simulator - zero-dependency static server.
//
// Serves the pre-built simulator in ./public. Uses only the Node standard
// library: there is nothing to npm install, and no network access is needed.
//
//   node start-simulator.mjs            # http://localhost:8080
//   node start-simulator.mjs 9090       # another port
//   PORT=9090 node start-simulator.mjs  # same, via the environment
//
// Single-page-app fallback is the important part: the robots open deep links
// such as /mivision/login, /dqm/login and /echamps/login directly. Those paths
// exist only inside the app's router, not on disk, so any request that is not a
// real file is answered with index.html. A plain static server (for example
// `python -m http.server`) returns 404 for them and every robot fails at login.

import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { join, extname, normalize, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = resolve(fileURLToPath(new URL('./public', import.meta.url)));
const PORT = Number(process.argv[2] || process.env.PORT || 8080);

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js':   'text/javascript; charset=utf-8',
  '.mjs':  'text/javascript; charset=utf-8',
  '.css':  'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg':  'image/svg+xml',
  '.png':  'image/png',
  '.jpg':  'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif':  'image/gif',
  '.ico':  'image/x-icon',
  '.webp': 'image/webp',
  '.woff': 'font/woff',
  '.woff2':'font/woff2',
  '.ttf':  'font/ttf',
  '.txt':  'text/plain; charset=utf-8',
  '.map':  'application/json; charset=utf-8',
};

async function sendFile(res, path, status = 200) {
  const body = await readFile(path);
  res.writeHead(status, {
    'Content-Type': TYPES[extname(path).toLowerCase()] || 'application/octet-stream',
    'Content-Length': body.length,
    'Cache-Control': 'no-cache',
  });
  res.end(body);
}

const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    const clean = normalize(decodeURIComponent(url.pathname)).replace(/^(\.\.[/\\])+/, '');
    const target = resolve(join(ROOT, clean));

    // Never serve anything outside ./public
    if (target !== ROOT && !target.startsWith(ROOT + sep)) {
      res.writeHead(403).end('Forbidden');
      return;
    }

    try {
      const info = await stat(target);
      if (info.isFile()) { await sendFile(res, target); return; }
    } catch { /* fall through to the SPA fallback */ }

    // A missing file under /assets/ is a real 404 - do not mask it with the app
    // shell, or a broken build looks like a blank page instead of an error.
    if (clean.startsWith('/assets/')) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not found: ' + clean);
      return;
    }

    await sendFile(res, join(ROOT, 'index.html'));          // SPA fallback
  } catch (err) {
    res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Server error: ' + err.message);
  }
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`\n  Port ${PORT} is already in use.`);
    console.error(`  Either stop whatever is using it, or start on another port:`);
    console.error(`      node start-simulator.mjs 9090`);
    console.error(`  If you change the port you MUST also set the simulatorBaseUrl`);
    console.error(`  process variable, e.g. {"simulatorBaseUrl":"http://localhost:9090"}\n`);
  } else {
    console.error('Failed to start:', err.message);
  }
  process.exit(1);
});

try { await stat(join(ROOT, 'index.html')); }
catch {
  console.error(`\n  Could not find public/index.html next to this script.`);
  console.error(`  Keep start-simulator.mjs and the public folder together.\n`);
  process.exit(1);
}

server.listen(PORT, () => {
  console.log(`\n  HSBC CCS System Simulator`);
  console.log(`  Serving ${ROOT}`);
  console.log(`  →  http://localhost:${PORT}\n`);
  if (PORT !== 8080) {
    console.log(`  NOTE: the robots default to port 8080. Because you are on ${PORT},`);
    console.log(`  set the process variable simulatorBaseUrl to http://localhost:${PORT}\n`);
  }
  console.log(`  Press Ctrl+C to stop.\n`);
});
