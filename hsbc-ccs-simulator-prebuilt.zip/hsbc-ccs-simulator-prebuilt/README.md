# HSBC CCS System Simulator — pre-built

The eight back-office screens the robots drive, **already built**. There is
nothing to install, nothing to compile, and no network access required.

## Requirements

- Node.js (any version from 18 onwards — 20 or 22 LTS recommended)

That is the whole list. No `npm install`, no registry access, no proxy
configuration, no C++ toolchain, no database, no credentials.

## Start it

**Windows** — double-click `start-simulator.bat`, or from PowerShell:

```powershell
node start-simulator.mjs
```

**macOS / Linux**

```bash
node start-simulator.mjs
```

Then open <http://localhost:8080>. You should see the system tiles and a
**Demo Cards** section listing the presenter cards. Leave it running.

Stop it with Ctrl+C.

## Ports

Port **8080** is where the robots look by default, so the default needs no
configuration.

To use a different port:

```bash
node start-simulator.mjs 9090
```

If you do, you **must** also tell the process, by setting the
`simulatorBaseUrl` process variable when you start a case:

```json
{ "simulatorBaseUrl": "http://localhost:9090" }
```

Note the spelling: the process variable is `simulatorBaseUrl` (camel case).
`SIMULATOR_BASE_URL` is the name used inside the RPA task mapping, one layer
further down — setting that as a process variable has no effect, and the robots
will silently keep looking at port 8080.

## Do not substitute a plain static server

The robots open deep links directly — `/mivision/login`, `/dqm/login`,
`/echamps/login` and the rest. Those paths exist only inside the app's router,
not on disk. `start-simulator.mjs` answers any non-file request with
`index.html`, which is what makes them work.

`python -m http.server` and most other simple static servers return **404** for
those paths, and every robot then fails at the login step while the home page
still looks perfectly healthy. If you must use your own web server, it has to do
single-page-app history fallback (nginx: `try_files $uri /index.html;`).

## What is in here

```
start-simulator.mjs   zero-dependency Node server (standard library only)
start-simulator.bat   Windows convenience wrapper
public/               the built application — 6 files, 884 KB
```

Nothing in `public/` is generated at run time. All simulator data lives in the
bundle and resets when the page is refreshed. This is a training simulator, not
a connection to any live system.

## When you need the full source package instead

Use this pre-built package to run the demo. You only need the full
`simulator/` source tree (and its ~300 npm packages) if you intend to **change**
the simulator — for example editing the seed cards to use your own customer
names and card numbers, as described in `SETUP-AND-CONFIGURATION.md` §2.2.
