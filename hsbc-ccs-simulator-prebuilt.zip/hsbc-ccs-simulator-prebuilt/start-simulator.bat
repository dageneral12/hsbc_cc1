@echo off
rem Double-click to start the simulator on http://localhost:8080
cd /d "%~dp0"
node start-simulator.mjs %*
pause
